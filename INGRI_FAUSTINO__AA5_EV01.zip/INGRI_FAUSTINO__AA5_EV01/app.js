// Configuración de Firebase (opcional, si sigues usando Firebase para autenticación)
const firebaseConfig = {
    apiKey: "TU_API_KEY",
    authDomain: "TU_PROYECTO.firebaseapp.com",
    projectId: "TU_PROYECTO",
    storageBucket: "TU_PROYECTO.appspot.com",
    messagingSenderId: "TU_SENDER_ID",
    appId: "TU_APP_ID"
};

// Inicializar Firebase (opcional)
firebase.initializeApp(firebaseConfig);

// Manejo del formulario de registro
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    // Obtener los valores del formulario
    const name = document.getElementById('name').value;
    const email = document.getElementById('newEmail').value;
    const password = document.getElementById('newPassword').value;

    // Crear el objeto de datos para enviar al backend
    const userData = {
        username: name, // Usamos el nombre como username
        password: password
    };

    try {
        // Enviar los datos al backend
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });

        // Verificar si la respuesta es exitosa
        if (response.ok) {
            const result = await response.json();
            console.log("Respuesta del servidor:", result.message);
            alert("Usuario registrado exitosamente");
            // Redirigir al usuario o mostrar el formulario de inicio de sesión
            document.querySelector('.register-container').style.display = 'none';
            document.querySelector('.login-container').style.display = 'block';
        } else {
            const error = await response.json();
            console.error("Error en el registro:", error.message);
            alert("Error en el registro: " + error.message);
        }
    } catch (error) {
        console.error("Error al enviar la solicitud:", error);
        alert("Error al conectar con el servidor");
    }
});

// Manejo del formulario de inicio de sesión (opcional, si usas Firebase)
document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    firebase.auth().signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
            console.log("Inicio de sesión exitoso:", userCredential.user);
        })
        .catch((error) => {
            console.error("Error al iniciar sesión:", error.message);
        });
});

// Inicio de sesión con Google (opcional, si usas Firebase)
document.getElementById('googleLogin').addEventListener('click', () => {
    const provider = new firebase.auth.GoogleAuthProvider();
    firebase.auth().signInWithPopup(provider)
        .then((result) => {
            console.log("Inicio de sesión con Google:", result.user);
        })
        .catch((error) => {
            console.error("Error al iniciar sesión con Google:", error.message);
        });
});

// Inicio de sesión con Facebook (opcional, si usas Firebase)
document.getElementById('facebookLogin').addEventListener('click', () => {
    const provider = new firebase.auth.FacebookAuthProvider();
    firebase.auth().signInWithPopup(provider)
        .then((result) => {
            console.log("Inicio de sesión con Facebook:", result.user);
        })
        .catch((error) => {
            console.error("Error al iniciar sesión con Facebook:", error.message);
        });
});

// Alternar entre inicio de sesión y registro
document.getElementById('registerLink').addEventListener('click', (e) => {
    e.preventDefault();
    document.querySelector('.login-container').style.display = 'none';
    document.querySelector('.register-container').style.display = 'block';
});

document.getElementById('loginLink').addEventListener('click', (e) => {
    e.preventDefault();
    document.querySelector('.register-container').style.display = 'none';
    document.querySelector('.login-container').style.display = 'block';
});