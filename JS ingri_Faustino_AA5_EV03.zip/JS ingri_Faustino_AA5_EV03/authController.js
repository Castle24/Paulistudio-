```javascript

// Simulación de una base de datos de usuarios

const users = [];
// Controlador para el registro de usuarios
const register = (req, res) => {
 const { username, password } = req.body;
 // Verificar si el usuario ya existe
 const userExists = users.find((user) => user.username === username);
 if (userExists) {
 return res.status(400).json({ message: "El usuario ya existe" });
 }
 // Almacenar el nuevo usuario

 users.push({ username, password });

 res.status(201).json({ message: "Usuario registrado exitosamente" });
};
// Controlador para el inicio de sesión

const login = (req, res) => {

 const { username, password } = req.body;
 // Buscar el usuario en la base de datos

 const user = users.find(

 (user) => user.username === username && user.password === password
 );
 if (user) {
 res.status(200).json({ message: "Autenticación satisfactoria" });
 } else {
 res.status(401).json({ message: "Error en la autenticación" });
 }
};
module.exports = { register, login };
```