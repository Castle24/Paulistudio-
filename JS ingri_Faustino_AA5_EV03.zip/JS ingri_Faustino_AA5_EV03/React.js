React JS
├── Componentes
│   ├── Funcionales (con Hooks)
│   └── De clase
├── JSX (Sintaxis similar a HTML)
├── Estado (State)
│   ├── useState (Hook)
│   └── this.state (Clases)
├── Props (Propiedades)
├── Eventos
│   ├── onClick
│   ├── onChange
│   └── onSubmit
├── Ciclo de vida
│   ├── componentDidMount
│   ├── componentDidUpdate
│   └── componentWillUnmount
├── Hooks
│   ├── useState
│   ├── useEffect
│   └── useContext
└── Virtual DOM (Optimización de rendimiento)