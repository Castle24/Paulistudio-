```jsx

import React from "react";

const Notificaciones = ({ mensaje }) => {
 return (
 <div className="notificaciones">
 <p>{mensaje}</p>
 </div>
 );
};
export default Notificaciones;
```