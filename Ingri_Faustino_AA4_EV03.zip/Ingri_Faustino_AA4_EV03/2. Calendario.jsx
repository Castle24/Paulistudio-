```jsx

import React, { useState } from "react";

const Calendario = ({ onSelectFecha }) => {
 const [fecha, setFecha] = useState("");
 const handleFechaChange = (e) => {
 setFecha(e.target.value);
 onSelectFecha(e.target.value);
 };
 return (
 <div className="calendario">
 <h2>Selecciona una Fecha</h2>
 <input type="date" value={fecha} onChange={handleFechaChange} />
 </div>
 );
};
export default Calendario;
```