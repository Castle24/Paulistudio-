```jsx

import React, { useState } from "react";

const AgendarCita = ({ servicio, fecha, onConfirm }) => {
 const [nombre, setNombre] = useState("");
 const handleConfirmar = () => {
 if (nombre && servicio && fecha) {

 onConfirm({ nombre, servicio, fecha });

 } else {
 alert("Por favor, completa todos los campos.");
 }
 };
 return (
 <div className="agendar-cita">
 <h2>Agendar Cita</h2>
 <input
 type="text"
 placeholder="Nombre completo"
 value={nombre}
 onChange={(e) => setNombre(e.target.value)}
 />
 <button onClick={handleConfirmar}>Confirmar Cita</button>
 </div>
 );
};
export default AgendarCita;
```
