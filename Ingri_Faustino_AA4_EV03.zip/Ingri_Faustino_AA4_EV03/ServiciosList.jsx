```jsx

import React from "react";

const ServiciosList = ({ servicios, onSelectServicio }) => {
 return (
 <div className="servicios-list">
 <h2>Servicios Disponibles</h2>
 <ul>
 {servicios.map((servicio) => (
 <li key={servicio.id} onClick={() => onSelectServicio(servicio)}>
 {servicio.nombre} - ${servicio.precio}
 </li>

 ))}

 </ul>
 </div>
 );
};
 
 